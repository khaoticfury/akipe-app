(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1aa689c5._.js",
  "static/chunks/node_modules_e8620f69._.js"
],
    source: "dynamic"
});
